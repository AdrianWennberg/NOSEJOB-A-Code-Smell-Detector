public class Fahrenheit implements HeatScalable {
	private double temperature;

	public Fahrenheit(double temperature) {
		this.temperature = temperature;
	}

	public double toFahrenheit() {
		return this.temperature;
	}

	public double toKelvin() {
		return (this.temperature + 459.67) * 5 / 9;
	}

	public double toCelsius() {
		return (this.temperature - 32) * 5 / 9;
	}

}
