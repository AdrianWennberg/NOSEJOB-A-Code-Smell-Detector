public class Celsius implements HeatScalable {
	private double temperature;

	public Celsius(double temperature) {
		this.temperature = temperature;
	}

	public double toCelsius() {
		return this.temperature;
	}

	public double toFahrenheit() {
		return this.temperature * 9 / 5 + 32;
	}

	public double toKelvin() {
		return this.temperature + 273.15;
	}

	public String toString() {

	}
}
