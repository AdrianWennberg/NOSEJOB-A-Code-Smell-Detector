public class Runner {
	public static void main(String[] args) {
		Celsius foo = new Celsius(50);
		System.out.println(foo.toKelvin());
	}
}
