public class Kelvin implements HeatScalable {
	private double temperature;

	public Kelvin(double temperature) {
		this.temperature = temperature;
	}

	public double toKelvin() {
		return this.temperature;
	}

	public double toCelsius() {
		return this.temperature - 273.15;
	}

	public double toFahrenheit() {
		return this.temperature * 9 / 5 - 459.67;
	}

}
